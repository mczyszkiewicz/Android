package com.example.mateusz.czyszkiewicz;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DataBaseHelper extends SQLiteOpenHelper{
	
	private static final String DATABASE_NAME = "database.db";
	private static final int DATABASE_VERSION = 6;

	public DataBaseHelper(Context context)
	{
		super(context,DATABASE_NAME,null,DATABASE_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase database) {
		WydatkiTable.OnCreate(database);
		TypTable.OnCreate(database);
		
	}

	@Override
	public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion) {
		WydatkiTable.onUpgrade(database, oldVersion, newVersion);
		TypTable.onUpgrade(database, oldVersion, newVersion);
		Log.d("zmiana","Dokonano zmiany tabel");
		
	}
}
