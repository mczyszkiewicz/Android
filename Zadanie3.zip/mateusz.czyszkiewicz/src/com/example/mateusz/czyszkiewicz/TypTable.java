package com.example.mateusz.czyszkiewicz;

import android.database.sqlite.SQLiteDatabase;

public class TypTable {

	private static final String TYP_TABLE = "typ";
	private static final String COLUMN_NAZWA = "nazwa";

	private static final String CREATE_DATABASE = "Create table " + TYP_TABLE
			+ "(" + COLUMN_NAZWA + " text not null );";

	public static void OnCreate(SQLiteDatabase database) {
		database.execSQL(CREATE_DATABASE);
	}

	public static void onUpgrade(SQLiteDatabase database, int oldVersion,
			int newVersion) {
		database.execSQL("Drop table if exists " + TYP_TABLE);
		OnCreate(database);
	}
}
