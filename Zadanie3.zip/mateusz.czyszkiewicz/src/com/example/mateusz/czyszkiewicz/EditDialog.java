package com.example.mateusz.czyszkiewicz;

import android.app.DialogFragment;
import android.content.ContentValues;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

public class EditDialog extends DialogFragment

{

	private Button button;
	private EditText wartosci;
	private EditText nazwy;
	private EditText typy;
	private EditText daty;
	Context context;
	private int position;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.edit_dialog, container);
		getDialog().setTitle("Edycja");
		button = (Button) view.findViewById(R.id.EditDialogbutton1);
		wartosci = (EditText) view.findViewById(R.id.EditDialogeditText4);
		nazwy = (EditText) view.findViewById(R.id.EditDialogeditText1);
		typy = (EditText) view.findViewById(R.id.EditDialogeditText2);
		daty = (EditText) view.findViewById(R.id.EditDialogeditText3);

		button.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				String typ = typy.getText().toString();
				String nazwa = nazwy.getText().toString();
				String tmp2 = wartosci.getText().toString();
				double wartosc = Double.parseDouble(tmp2);
				String data = daty.getText().toString();

				ContentValues updatevalues = new ContentValues();
				updatevalues.put(WydatkiTable.COLUMN_NAZWA, nazwa);
				updatevalues.put(WydatkiTable.COLUMN_TYP, typ);
				updatevalues.put(WydatkiTable.COLUMN_WARTOSC, wartosc);
				updatevalues.put(WydatkiTable.COLUMN_DATA, data);
				position++;
				String where = "_id ==" + String.valueOf(position);
				getActivity().getContentResolver().update(
						MyContentProvider.WYDATKI_URI, updatevalues, where,
						null);

				dismiss();
			}

		});

		return view;
	}

	public void position(int pos) {
		position = pos;
	}

}
