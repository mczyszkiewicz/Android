package com.example.mateusz.czyszkiewicz;

import android.app.DialogFragment;
import android.content.ContentValues;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MyDialog extends DialogFragment {

	private Button button;
	private EditText wartosci;
	private EditText nazwy;
	private EditText typy;
	private EditText daty;
	Context context;

	public MyDialog() {
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.dialog, container);
		getDialog().setTitle(R.string.addm);
		button = (Button) view.findViewById(R.id.button1);
		wartosci = (EditText) view.findViewById(R.id.editText4);
		nazwy = (EditText) view.findViewById(R.id.editText1);
		typy = (EditText) view.findViewById(R.id.editText2);
		daty = (EditText) view.findViewById(R.id.editText3);

		button.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				String tmp = typy.getText().toString();
				int typ = Integer.parseInt(tmp);
				String nazwa = nazwy.getText().toString();
				String tmp2 = wartosci.getText().toString();
				double wartosc = Double.parseDouble(tmp2);
				String data = daty.getText().toString();
				ContentValues values = new ContentValues();
				values.put(WydatkiTable.COLUMN_NAZWA, nazwa);
				values.put(WydatkiTable.COLUMN_TYP, typ);
				values.put(WydatkiTable.COLUMN_WARTOSC, wartosc);
				values.put(WydatkiTable.COLUMN_DATA, data);
				getActivity().getContentResolver().insert(
						MyContentProvider.WYDATKI_URI, values);
				Toast.makeText(getActivity(), "Dodano wpis do bazy",
						Toast.LENGTH_SHORT).show();

				dismiss();

			}
		});

		return view;
	}

	

}
