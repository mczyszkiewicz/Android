/** Automatically generated file. DO NOT MODIFY */
package com.example.mateusz.czyszkiewicz;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}